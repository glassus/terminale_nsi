def pascal(n):
    triangle= [[1]]
    for k in range(1,...):
        ligne_k = [...]
        for i in range(1,k):
            ligne_k.append(triangle[...][i-1]+triangle[...][...])
        ligne_k.append(...)
        triangle.append(ligne_k)
    return triangle
